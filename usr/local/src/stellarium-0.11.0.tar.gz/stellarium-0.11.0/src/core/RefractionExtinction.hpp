/*
 * Stellarium
 * Copyright (C) 2010 Fabien Chereau
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Refraction and extinction computations.
 * Implementation: 2010-03-23 GZ=Georg Zotti, Georg.Zotti@univie.ac.at
 * 2010-12 FC split into 2 classes, implemented Refraction */

#ifndef _REFRACTIONEXTINCTION_HPP_
#define _REFRACTIONEXTINCTION_HPP_
// USABILITY: added 3 more flags/switches in GUI:
// Temperature [C] [influences refraction]
// Pressure [mbar]  [influences refraction]
// extinction Coeff. k=0...(0.01)...1, [if k=0, no ext. effect]
// SUGGESTION: Allow Temperature/Pressure/ex.Coeff./LightPollution set in the landscape files

#include "VecMath.hpp"
#include "StelProjector.hpp"

//! @class RefractionExtinction
//! This class performs refraction and extinction computations, following literature from atmospheric optics and astronomy.
//! Airmass computations are limited to meaningful altitudes,
//! and refraction solutions can only be aproximate, given the turbulent, unpredictable real atmosphere.
//! The solution provided here will [hopefully!] result in a visible "zone of avoidance" near the horizon down to altitude -2,
//! and will show stars in their full brightness at their geometrical positions below -5 degrees.
//! Of course, plotting stars below the horizon could be coupled to setting of horizon foreground,
//! it's another usability issue. Typical horizons do not go down below -1, so strange effects between -2 and -5 should be covered.
//! Note that forward/backward are no absolute reverse operations!
//! All the computations should be in effect
//! (1) only if atmosphere effects are true
//! (2) only for celestial objects, never for landscape coordinates
//! (3) only for terrestrial locations, not on Moon/Mars/Saturn etc
class Extinction
{
public:
	Extinction();
	//! Compute extinction effect for arrays of size @param num position vectors and magnitudes.
	//! @param altAzPos are the normalized (apparent) star position vectors, and their z components sin(apparent_altitude).
	//! This call must therefore be done after application of Refraction, and only if atmospheric effects are on.
	//! Note that forward/backward are no absolute reverse operations!
	void forward(const Vec3d *altAzPos, float *mag, const int num) const;
	void forward(const Vec3f *altAzPos, float *mag, const int num) const;
	//! Convenience method for the same
	void forward(const double *sinAlt,  float *mag, const int num) const;
	void forward(const float  *sinAlt,  float *mag, const int num) const;

	//! Compute extinction effect for arrays of size @param size position vectors and magnitudes.
	//! @param altAzPos are the normalized (apparent) star position vectors, and their z components sin(apparent_altitude).
	//! Note that forward/backward are no absolute reverse operations!
	void backward(const Vec3d *altAzPos, float *mag, const int num) const;
	void backward(const Vec3f *altAzPos, float *mag, const int num) const;
	//! Convenience method for the same
	void backward(const double *sinAlt,  float *mag, const int num) const;
	void backward(const float  *sinAlt,  float *mag, const int num) const;

	//! Set visual extinction coefficient (mag/airmass), influences extinction computation.
	//! @param k= 0.1 for highest mountains, 0.2 for very good lowland locations, 0.35 for typical lowland, 0.5 in humid climates.
	void setExtinctionCoefficient(float k) { ext_coeff=k; }
	float getExtinctionCoefficient() const {return ext_coeff;}

private:
	//! airmass computation for @param cosZ = cosine of zenith angle z (=sin(altitude)!).
	//! The default (@param apparent_z = true) is computing airmass from observed altitude, following Rozenberg (1966) [X(90)~40].
	//! if (@param apparent_z = false), we have geometrical altitude and compute airmass from that,
	//! following Young: Air mass and refraction. Applied Optics 33(6), pp.1108-1110, 1994. [X(90)~32].
	//! A problem ist that refraction depends on air pressure and temperature, but Young's formula assumes T=15C, p=1013.25mbar.
	//! So, it seems better to compute refraction first, and then use the Rozenberg formula here.
	//! Rozenberg is infinite at Z=92.17 deg, Young at Z=93.6 deg, so this function RETURNS SUBHORIZONTAL_AIRMASS BELOW -2 DEGREES!
	float airmass(const float cosZ, const bool apparent_z=true) const;

	//! k, magnitudes/airmass, in [0.00, ... 1.00], (default 0.20).
	float ext_coeff;
	//! should be either 0.0 (stars visible in full brightness below horizon) or 40.0 (practically invisible)
	//! Maybe make this a user-configurable option?
	static const float SUBHORIZONTAL_AIRMASS;
};


class Refraction: public StelProjector::ModelViewTranform
{
public:
	Refraction();

	//! Apply refraction.
	//! @param altAzPos is the geometrical star position vector, to be transformed into apparent position.
	//! Note that forward/backward are no absolute reverse operations!
	void forward(Vec3d& altAzPos) const;

	//! Remove refraction from position ("reduce").
	//! @param altAzPos is the apparent star position vector, to be transformed into geometrical position.
	//! Note that forward/backward are no absolute reverse operations!
	void backward(Vec3d& altAzPos) const;

	//! Apply refraction.
	//! @param altAzPos is the geometrical star position vector, to be transformed into apparent position.
	//! Note that forward/backward are no absolute reverse operations!
	void forward(Vec3f& altAzPos) const;

	//! Remove refraction from position ("reduce").
	//! @param altAzPos is the apparent star position vector, to be transformed into geometrical position.
	//! Note that forward/backward are no absolute reverse operations!
	void backward(Vec3f& altAzPos) const;

	void combine(const Mat4d& m)
	{
		setPreTransfoMat(preTransfoMat*m);
	}

	Mat4d getApproximateLinearTransfo() const {return postTransfoMat*preTransfoMat;}

	StelProjector::ModelViewTranformP clone() const {Refraction* refr = new Refraction(); *refr=*this; return StelProjector::ModelViewTranformP(refr);}

	//! Set surface air pressure (mbars), influences refraction computation.
	void setPressure(float p_mbar);
	float getPressure() const {return pressure;}

	//! Set surface air temperature (degrees Celsius), influences refraction computation.
	void setTemperature(float t_C);
	float getTemperature() const {return temperature;}

	//! Set the transformation matrices used to transform input vector to AltAz frame.
	void setPreTransfoMat(const Mat4d& m);
	void setPostTransfoMat(const Mat4d& m);

private:
	//! Update precomputed variables.
	void updatePrecomputed();

	//! These 3 Atmosphere parameters can be controlled by GUI.
	//! Pressure[mbar] (1013)
	float pressure;
	//! Temperature[Celsius deg] (10).
	float temperature;
	//! Numerator of refraction formula, to be cached for speed.
	float press_temp_corr_Saemundson;
	//! Numerator of refraction formula, to be cached for speed.
	float press_temp_corr_Bennett;

	//! These constants are usable for experiments with the limits of refraction effects.
	static const double MIN_GEO_ALTITUDE_DEG;
	static const double MIN_GEO_ALTITUDE_RAD;
	static const double MIN_GEO_ALTITUDE_SIN;
	static const double MIN_APP_ALTITUDE_DEG;
	static const double MIN_APP_ALTITUDE_RAD;
	static const double MIN_APP_ALTITUDE_SIN;
	static const float MIN_GEO_ALTITUDE_DEG_F;
	static const float MIN_GEO_ALTITUDE_RAD_F;
	static const float MIN_GEO_ALTITUDE_SIN_F;
	static const float MIN_APP_ALTITUDE_DEG_F;
	static const float MIN_APP_ALTITUDE_RAD_F;
	static const float MIN_APP_ALTITUDE_SIN_F;
	static const double TRANSITION_WIDTH_GEO_DEG;
	static const double TRANSITION_WIDTH_GEO_DEG_F;
	static const double TRANSITION_WIDTH_APP_DEG;
	static const double TRANSITION_WIDTH_APP_DEG_F;

	//! Used to pretransform coordinates into AltAz frame.
	Mat4d preTransfoMat;
	Mat4d invertPreTransfoMat;
	Mat4f preTransfoMatf;
	Mat4f invertPreTransfoMatf;

	//! Used to postransform refracted coordinates from AltAz to view.
	Mat4d postTransfoMat;
	Mat4d invertPostTransfoMat;
	Mat4f postTransfoMatf;
	Mat4f invertPostTransfoMatf;
};

#endif  // _REFRACTIONEXTINCTION_HPP_
