#ifndef _LANGINFO_H
#define _LANGINFO_H

#ifdef __cplusplus
extern "C" {
#endif

#include "kdewin32/nl_types.h"

char *nl_langinfo(nl_item);

#ifdef __cplusplus
}
#endif

#endif  // _LANGINFO_H
