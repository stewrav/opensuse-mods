These files come from the KDE library, in the kdecore/compression package.
The license for all of them is LGPL v2.

They were slightly modified to remove any KDE specific dependencies,
see http://websvn.kde.org/trunk/KDE/kdelibs/kdecore/compression/ to get the original versions.

The files related to ZIP archive were modified to avoid KDE dependencies, and they don't support writting archive, only reading.

Fabien Chereau - 2008-09-23